import React from 'react';

const index = () => {
    return (
        <div  style={{ paddingLeft: '120px' }}>
            Feature Request
        </div>
    );
};

export default index;