import React from 'react';

const index = () => {
    return (
        <div  style={{ paddingLeft: '120px' }}>
            Template
        </div>
    );
};

export default index;