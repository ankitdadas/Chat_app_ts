import React from 'react';

const index = () => {
    return (
        <div  style={{ paddingLeft: '120px' }}>
            Insight
        </div>
    );
};

export default index;